#include <stdio.h>
void  print(int A[], int n)
{
    int i = 0;
    for (i = 0; i < n; i++)
        printf("%d ", A[i]);
}
int  MERGE(int A[], int p, int q, int r)
{
    int i,j,count=0;
   
   int m=q-p+1;
   int size=r-q;
   int left[m+1],right[size+1];
   for(i=0;i<m;i++)
   {
   left[i]=A[p+i];
   }
   for(j=0;j<size;j++)
   {
   right[j]=A[q+j+1];
   }
   left[m]=1001;
   right[size]=1001;
   i=0;j=0;
   for(int k=p;k<=r;k++)
   {
       if(left[i]<=right[j])
       {
           A[k]=left[i];
           i++;
           count++;
       }
       else
        {
            A[k]=right[j];
            j++;
            count++;
        }
   }

return count;
}
int MERGESORT(int A[], int p, int r)
{
    int q,count=0;
    if (p < r)
    {
       
        q = (p + r) / 2;
        count+=MERGESORT(A,p,q);
        count+=MERGESORT(A,q+1,r);
        count+=MERGE(A,p,q,r);
    }
    return count;
}
int main()
{
    int n;
    scanf("%d",&n);
    int A[n];
    for (int i = 0; i <n;i++)
    {
        scanf("%d", &A[i]);
    }
   int  count=MERGESORT(A,0,n-1);
    print(A,n);
    printf("\n%d",count);

    return 0;
}