#include<stdio.h>
void sort(int a[],int n)
{
    int i,j,temp;
    for(i =1;i<n;i++)
    {
        j=i-1;
        temp=a[i];
        while (temp<a[j] && j>=0)
        {
            a[j+1]=a[j];
            j--;
        }
        a[j+1]=temp;
        
    }
}
int bsearch(int a[], int start, int end, int key)
{
    int mid = (start + end) / 2;
    if (start > end)
   { 
       
        return -1;}
    if (key == a[mid])
    {
    
        return mid;}
    if (key < a[mid])
    {
      
        return bsearch(a, start, mid - 1, key);
    }
    if (key>a[mid])
    {
        
        return bsearch(a, mid+1,end,key);
    }
    
}
int main()
{
int m,n,f;
scanf("%d%d",&m,&n);
int A[m],B[n],i,j;
int start=0,end=m-1;
for( i = 0; i < m; i++)
{
    scanf("%d", &A[i]);
}
for( j = n-1; j >= 0; j--)
{
    scanf("%d", &B[j]);
    
}
 

for(j=0; j < n; j++)
{
    sort(A,m);
    
    f=bsearch(A,start,end,B[j]);
    // printf(" %d",f);
    if(f!=-1)
    {
        printf("%d ",B[j]);
        
        // f=-1;
        A[f]=99999999;
    }
    // f=bsearch(a,start,end,b[j]);
    
}
    
return 0;
}