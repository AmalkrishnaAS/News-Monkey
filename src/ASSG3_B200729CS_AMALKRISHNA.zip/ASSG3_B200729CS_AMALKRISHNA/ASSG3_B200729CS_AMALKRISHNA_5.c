#include <stdio.h>

void  MERGE(int A[], int p, int q, int r,int count[])
{
    int i,j;
   
   int m=q-p+1,y=p;
   int size=r-q;
   long long int left[m+1],right[size+1];
   for(i=0;i<m;i++)
   {
   left[i]=A[p+i];
   }
   for(j=0;j<size;j++)
   {
   right[j]=A[q+j+1];
   }
   left[m]=99999999;
   right[size]=99999999;
   i=0;j=0;
   for(int k=p;k<=r;k++)
   {
       if(left[i]<right[j])
       {
           A[k]=left[i];
           
           count[0]++;
           i++;
           y++;

           
       }
       if(left[i]>right[j])
        {
            A[k]=right[j];
            j++;
            count[1]=count[1]+(q-y+1);
            count[0]++;
            
        }
   }


}
void MERGESORT(int A[], int p, int r,int count[])
{
    int q;
    if (p < r)
    {
        
       
        q = (p + r) / 2;
        MERGESORT(A,p,q,count);
        MERGESORT(A,q+1,r,count);
        MERGE(A,p,q,r,count);
    }
    
}
int main()
{
    int n,count[2]={0,0};
    scanf("%d",&n);
    int a[n];
    for (int i = 0; i <n;i++)
    {
        scanf("%d", &a[i]);
    }
     MERGESORT(a,0,n-1,count);
    // print(a,n);
    printf("%d",count[1]);
    printf("\n%d",count[0]);

    return 0;
}