#include <stdio.h>
 int call_count;
 
int bsearch (int a[], int start, int end,int key)
{
   int mid= (start + end) / 2;
   if(start > end)
   {
       return -1;
   }
   if(key ==a[mid])
   {
       if(mid==0)
       {
           return 0;
       }
       if(a[mid]==a[mid-1])
       { ++call_count;
           return bsearch(a,start,mid-1,key);
       }
       return mid;
   }
   if(key<a[mid])
   { ++call_count;
       return bsearch(a,start,mid-1,key);
   }
   if(key>a[mid])
   { ++call_count;
       return bsearch(a,mid+1,end,key);
   }
}

int main()
{
 int n,i,j,key,start=0,index=-1;
 scanf("%d",&n);
 int A[n];
 for (i=0;i<n;i++)
 {
     scanf("%d", &A[i]);
 }
 scanf("%d", &key);
int end=n-1;
++call_count;
index=bsearch(A,start,end,key);
printf("%d\n%d",index,call_count);
    return 0;
}